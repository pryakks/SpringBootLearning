package com.auth.server.repos;

import com.auth.server.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepo extends JpaRepository<Role, Long> {

}
